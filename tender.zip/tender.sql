-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 18, 2022 at 10:33 PM
-- Server version: 5.6.51-cll-lve
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tender`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`) VALUES
(1, 'yadav.systos@gmail.com', '123\r\n\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `company-user`
--

CREATE TABLE `company-user` (
  `id` int(11) NOT NULL,
  `user-type` varchar(200) NOT NULL,
  `company_name` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` varchar(100) NOT NULL,
  `gst_number` varchar(100) NOT NULL,
  `labour_license` varchar(100) NOT NULL,
  `pan_number` varchar(100) NOT NULL,
  `password` varchar(21) NOT NULL,
  `about_me` varchar(500) NOT NULL,
  `image` varchar(200) NOT NULL,
  `project_handle` longtext NOT NULL,
  `current_project` longtext NOT NULL,
  `past_project` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company-user`
--

INSERT INTO `company-user` (`id`, `user-type`, `company_name`, `email`, `number`, `gst_number`, `labour_license`, `pan_number`, `password`, `about_me`, `image`, `project_handle`, `current_project`, `past_project`) VALUES
(1, 'company', 'ASHISH', 'ashish.systos1620@gmail.com', '9131072227', '11ASDSDS1FDS131', '454464', 'GGHG546', 'aSHISH@123', 'TEST', 'location.png', 'test2', 'test2', 'test2'),
(2, 'company', 'adani infotech', 'yadav.systos@systos.gmail.com', '9876543210', '5465545JGFFF5', '98965538', 'AWMPY2555Q', '123456', 'Hey Dud', 'logo.png', '1. lorem ipsum sit amet ', '1. lorem ipsum sit amet ', '1. lorem ipsum sit amet ');

-- --------------------------------------------------------

--
-- Table structure for table `vendor-user`
--

CREATE TABLE `vendor-user` (
  `id` int(11) NOT NULL,
  `user-type` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` varchar(100) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `gst_number` varchar(100) NOT NULL,
  `labour_license` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `about_me` varchar(100) NOT NULL,
  `image` varchar(200) NOT NULL,
  `project_handle` longtext NOT NULL,
  `current_project` longtext NOT NULL,
  `past_project` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendor-user`
--

INSERT INTO `vendor-user` (`id`, `user-type`, `name`, `email`, `number`, `company_name`, `gst_number`, `labour_license`, `password`, `about_me`, `image`, `project_handle`, `current_project`, `past_project`) VALUES
(1, 'vendor', 'Chhotu yadav', 'yadav.systos@gmail.com', '9876543210', 'adani infotech', 'HDKHDF48577HFDD', '789654123', '123456', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the', 'contact.png', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available.', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available.', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available.'),
(2, 'vendor', 'Ashish', 'ashish.systos1620@gmail.com', '9131072227', 'systos', '124AJDJKJKNB123', '454464', 'aSHISH@123', 'TEST', 'youtube.png', 'ghgfh', 'dfgz', 'ggdf');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company-user`
--
ALTER TABLE `company-user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vendor-user`
--
ALTER TABLE `vendor-user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `company-user`
--
ALTER TABLE `company-user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vendor-user`
--
ALTER TABLE `vendor-user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
