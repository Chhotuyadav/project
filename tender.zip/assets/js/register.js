 var currentTab = 0; // Current tab is set to be the first tab (0)
        showTab(currentTab); // Display the current tab
        
        function showTab(n) {
          // This function will display the specified tab of the form...
          var x = document.getElementsByClassName("step");
          x[n].style.display = "block";
          //... and fix the Previous/Next buttons:
          if (n == 0) {
            document.getElementById("prevBtn").style.display = "none";
            document.getElementById("subbtn").style.display = "none";
            document.getElementById("nextBtn").style.display = "block";
          } else {
            document.getElementById("prevBtn").style.display = "inline";
          }
          if (n == (x.length - 1)) {
            document.getElementById("nextBtn").innerHTML = "Submit";
            document.getElementById("nextBtn").style.display = "none";
            document.getElementById("subbtn").style.display = "block";
          } else {
            document.getElementById("nextBtn").innerHTML = "Next";
          }
          //... and run a function that will display the correct step indicator:
          fixStepIndicator(n)
        }
        
        function nextPrev(n) {
          // This function will figure out which tab to display
          var x = document.getElementsByClassName("step");
          // Exit the function if any field in the current tab is invalid:
          if (n == 1 && !validateForm()) return false;
          // Hide the current tab:
          x[currentTab].style.display = "none";
          // Increase or decrease the current tab by 1:
          currentTab = currentTab + n;
          // if you have reached the end of the form...
          if (currentTab >= x.length) {
            // ... the form gets submitted:
            document.getElementById("signUpForm").submit();
            return false;
          }
          // Otherwise, display the correct tab:
          showTab(currentTab);
        }
        
        function validateForm() {
          // This function deals with validation of the form fields
          var x, y, i, valid = true;
          x = document.getElementsByClassName("step");
          y = x[currentTab].getElementsByTagName("input");
          // A loop that checks every input field in the current tab:
          for (i = 0; i < y.length; i++) {
            // If a field is empty...
            if (y[i].value == "") {
              // add an "invalid" class to the field:
              y[i].className += " invalid";
              // and set the current valid status to false
              valid = false;
            }
          }
          // If the valid status is true, mark the step as finished and valid:
          if (valid) {
            document.getElementsByClassName("stepIndicator")[currentTab].className += " finish";
          }
          return valid; // return the valid status
        }
        
        function fixStepIndicator(n) {
          // This function removes the "active" class of all steps...
          var i, x = document.getElementsByClassName("stepIndicator");
          for (i = 0; i < x.length; i++) {
            x[i].className = x[i].className.replace(" active", "");
          }
          //... and adds the "active" class on the current step:
          x[n].className += " active";
        }


        /*REGISTER FORM SEND DATA TO ROUTTE*/

     $('body').on('submit','.register-vender',function(e){
      e.preventDefault()

        var formData = new FormData(this)        
       
        var res = insertData("register-vender","POST",formData)

        if (res.status) {
          //showMsg('success',msg);
           alert(res.msg)
          window.location.href = url;
        }else{
          //showMsg('danger',msg);
            alert(res.msg)
            $( this ).focus();
          // $('#exampleModalCenter').modal('hide')
        }
          
    })

     /*company register*/

     $('body').on('submit','.company-register',function(e){
      e.preventDefault()

        var formData = new FormData(this)        
       
        var res = insertData("company-register","POST",formData)

        if (res.status) {
          //showMsg('success',msg);
           alert(res.msg)
          window.location.href = url;
        }else{
          //showMsg('danger',msg);
            alert(res.msg)
            $( this ).focus();
          // $('#exampleModalCenter').modal('hide')
        }
          
    })


     function insertData(url, method, data) {
        // alert('ok')
        // console.log(data)
        var dataToReturn = "";
        $.ajax({
            url: url,
            method: method,
            async: false,
            data: data,
            contentType: false,
            processData: false,
            success: function (response) {
                var responseObj = $.parseJSON(response);
                dataToReturn = responseObj;
            }
        });
        return dataToReturn;
    }

    /*register data vedor company*/
    var user_type = '';

    $('body').on('click','input[name=user-type]',function(){


        var val = $(this).val()
        
        console.log(val)
            user_type = val


        if(val == 'company'){
            $("#signUpForm").addClass('company-register');
            $('#signUpForm').removeClass('register-vender')

            $('.next-btn').removeClass('d-none')
            $('.vendor-form').addClass('d-none')
            $('.company-name').removeClass('d-none')
          
        }

        if(val == 'vendor'){
            $("#signUpForm").addClass('register-vender');
            $('#signUpForm').removeClass('company-register')

            $('.next-btn').removeClass('d-none')
            $('.company-name').addClass('d-none')
            $('.vendor-form').removeClass('d-none')
          
        }

    });


$(document).ready(function(){

$('#emailvalid').hide();
$('#checknumber').hide();
$('#checkgst').hide();
$('#checklicense').hide();
$('#usercheck').hide();
$('#passcheck').hide();
$('#conpasscheck').hide();


var user_err = true;
var pass_err = true;
var conpass_err = true;
var number_err = true;
var email_err = true;
var gst_err = true;

$('#number').keyup(function(){
usernumber_check();
});

function usernumber_check(){

var user_val = $('#number').val();

if(user_val.length == ''){
$('#checknumber').show();
$('#checknumber').html("**Please Fill the number");
$('#checknumber').focus();
$('#checknumber').css("color","red");
user_err = false;
return false;

}else{
$('#checknumber').hide();
}

if(user_val.length == 9 ) {
$('#checknumber').show();
$('#checknumber').html("**Mobile length must be 10");
$('#checknumber').focus();
$('#checknumber').css("color","red");
number_err = false;
return false;

}else{
$('#checknumber').hide();
}

}

/*gst*/
$('#gst').keyup(function(){
usergst_check();
});

function usergst_check(){

var user_gst = $('#gst').val();
/*var gstinformat = new RegExp('^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]1}[1-9A-Z]{1}Z[0-9A-Z]{1}$');  */ 
if(user_gst.length == ''){
$('#checkgst').show();
$('#checkgst').html("**GST Number should be in this format *11AAAAA1111Z1A1* ");
$('#checkgst').focus();
$('#checkgst').css("color","red");
gst_err = false;
return false;

}else{
$('#checkgst').hide();
}

if(user_gst.length == 14 ) {
$('#checkgst').show();
$('#checkgst').html("**GST no. length must be 15");
$('#checkgst').focus();
$('#checkgst').css("color","red");
gst_err = false;
return false;

}else{
$('#checkgst').hide();
}

}




/*psw*/
$('#password').keyup(function(){
password_check();
});

function password_check(){

var passwrdstr = $('#password').val();

if(passwrdstr.length == ''){
$('#passcheck').show();
$('#passcheck').html("**Please Fill the password");
$('#passcheck').focus();
$('#passcheck').css("color","red");
pass_err = false;
return false;

}else{
$('#passcheck').hide();
}

if((passwrdstr.length < 6 ) || (passwrdstr.length > 21 ) ){
$('#passcheck').show();
$('#passcheck').html("**password length must be between 6 and 21");
$('#passcheck').focus();
$('#passcheck').css("color","red");
pass_err = false;
return false;

}else{
$('#passcheck').hide();
}
}

$('#conpassword').keyup(function(){
con_passwrd();
});

function con_passwrd(){

var conpass = $('#conpassword').val();
var passwrdstr = $('#password').val();

if(passwrdstr != conpass){
$('#conpasscheck').show();
$('#conpasscheck').html("** Password are not Matching");
$('#conpasscheck').focus();
$('#conpasscheck').css("color","red");
conpass_err = false;
return false;

}else{
$('#conpasscheck').hide();
}

}

$('#submitbtn').click(function(){

user_err = true;
pass_err = true;
conpass_err = true;

username_check();
password_check();
con_passwrd();

if((user_err == true ) && (pass_err == true) && (conpass_err == true) ){
return true;
}else{
return false;
}

});

});