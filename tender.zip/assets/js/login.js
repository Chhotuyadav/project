
        $('body').on('submit','.login-vender',function(e){
         e.preventDefault()

           var formData = new FormData(this)        
          
           var res = insertData("login-vender","POST",formData)

           if (res.status) {
              //showMsg('success',msg);
              alert(res.msg)
              window.location.href = 'vendor-dashboard';
           }else{
              //showMsg('danger',msg);
              alert(res.msg)
              //window.location.href = url;
             // $('#exampleModalCenter').modal('hide')
           }
             
       })

        /*company login*/
        
        $('body').on('submit','.company-login',function(e){
         e.preventDefault()

           var formData = new FormData(this)        
          
           var res = insertData("company-login","POST",formData)

           if (res.status) {
              //showMsg('success',msg);
              alert(res.msg)
              window.location.href = 'company-dashboard';
           }else{
              //showMsg('danger',msg);
              alert(res.msg)
              //window.location.href = url;
             // $('#exampleModalCenter').modal('hide')
           }
             
       })




     function insertData(url, method, data) {
        // alert('ok')
        // console.log(data)
        var dataToReturn = "";
        $.ajax({
            url: url,
            method: method,
            async: false,
            data: data,
            contentType: false,
            processData: false,
            success: function (response) {
                var responseObj = $.parseJSON(response);
                dataToReturn = responseObj;
            }
        });
        return dataToReturn;
    }

    /*login check user type*/

    var user_type = '';

    $('body').on('click','input[name=user-type]',function(){


        var val = $(this).val()
        
        console.log(val)
            user_type = val

        if(val == 'vendor'){
            $("#loginForm").addClass('login-vender');
            $('#loginForm').removeClass('company-login')

        }
        
        if(val == 'company'){
            $("#loginForm").addClass('company-login');
            $('#loginForm').removeClass('login-vender')
          
        }

    });


    /*update vendor*/

    $('body').on('submit','.update-vender',function(e){
         e.preventDefault()

           var formData = new FormData(this)        
          
           var res = insertData("update-vender","POST",formData)

           if (res.status) {
              alert(res.msg)
              location.reload();
           }else{              
              alert(res.msg)
           }
             
       })

        /*update Company*/

    $('body').on('submit','.update-company',function(e){
         e.preventDefault()

           var formData = new FormData(this)        
          
           var res = insertData("update-company","POST",formData)

           if (res.status) {
              alert(res.msg)
              location.reload();
           }else{              
              alert(res.msg)
           }
             
       })





