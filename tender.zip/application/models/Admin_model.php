<?php

class Admin_model extends CI_Model{

	public function admin_check($email,$password){
		$this->db->where('email',$email);
		$this->db->where('password',$password);
		$res = $this->db->get('admin');
		return $res->result();
	}

}