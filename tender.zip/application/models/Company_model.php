<?php

class Company_model extends CI_Model{

	public function register_company_data($data){

		$this->db->insert('company-user', $data);

		return true;
	}


	/*email check*/

	public function email_check($email){
		$res = $this->db->where('email',$email);
        $res =  $this->db->get('company-user');
		return $res->result();
	}
	public function gst_check($gst_number){
		$res =  $this->db->where('gst_number',$gst_number);
        $res = $this->db->get('company-user');
		return $res->result();
	}
	public function pan_check($pan_number){
		$res =  $this->db->where('pan_number',$pan_number);
        $res = $this->db->get('company-user');
		return $res->result();
	}

	public function username_check_company($username){
		$res =$this->db->where('email',$username);
        $res = $this->db->get('company-user');
		return $res->result();
	}

	public function check_pass($password){
		$res=  $this->db->where('password',$password);
        $res = $this->db->get('company-user');
		return $res->result();
	}

	public function login_company_data($username,$password){
		$res=$this->db->where('email',$username);
		//$this->db->where('number',$number);
		$res =$this->db->where('password',$password);
		$res = $this->db->get('company-user');
		return $res->result();
	}

	public function get_company_details($company_id){
		$res =$this->db->where('id',$company_id);
        $res = $this->db->get('company-user');
		return $res->result();
	}

	/*change profile*/

	public function vender_profile_img($id,$data){
		$this->db->where('id',$id);
        $this->db->update('company-user',$data);
		return true;
	}

	/*update_company*/

	public function update_company_date($id,$data){
		$this->db->where('id',$id);
        $this->db->update('company-user',$data);
		return true;	
	}
	

	
}