<?php

class Vendor_model extends CI_Model{

	public function register_vender_date($data){

		$this->db->insert('vendor-user', $data);

		return true;
	}

	/*email check*/

	public function username_check($username){
		$this->db->where('email',$username);
        $res = $this->db->get('vendor-user');
		return $res->result();
	}

	public function email_check_register($email){
		$res = $this->db->where('email',$email);
        $res =  $this->db->get('vendor-user');
		return $res->result();
	}
	public function gst_check($gst_number){
		$res =  $this->db->where('gst_number',$gst_number);
        $res = $this->db->get('vendor-user');
		return $res->result();
	}

	public function check_pass($password){
		$this->db->where('password',$password);
        $res = $this->db->get('vendor-user');
		return $res->result();
	}

	public function login_vender_data($username,$password){
		$this->db->where('email',$username);
		$this->db->where('password',$password);
		$res = $this->db->get('vendor-user');
		return $res->result();
	}

	/*get vendor*/

	public function get_vendor_details($Vendor_id){
		$res = $this->db->where('id',$Vendor_id);
		$res =$this->db->get('vendor-user');
		return $res->result();
	}

	/*imge update*/

	public function vender_profile_img($id,$data){
		$this->db->where('id',$id);
		$this->db->update('vendor-user',$data);
		return true;
	}

	/*update_vender_data*/

	public function update_vender_data($id,$data){
		$this->db->where('id',$id);
		$this->db->update('vendor-user',$data);
		return true;
	}


}