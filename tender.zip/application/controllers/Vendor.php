<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vendor extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('Vendor_model');

		
	}

	/*register_vender*/

	public function register_vender(){


		 $vendor_name  =  $this->input->post('name');
		 $email  =  $this->input->post('email');
		 $gst_number  =  $this->input->post('gst-number');

		if ($vendor_name == '' ) {
			$dataToReturn['status']   =  false;
	        $dataToReturn['msg']      =  'Enter Name';
	        echo json_encode($dataToReturn);
	        die();
		}

		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
	        $dataToReturn['status']   =  false;
	        $dataToReturn['msg']      =  'Enter Valid Email';
	        echo json_encode($dataToReturn);
	        die();
        }

		$email_check = $this->Vendor_model->email_check_register($email);

		if (!empty($email_check)) {
			$dataToReturn['status']   =  false;
	        $dataToReturn['msg']      =  'Email Already Exist';
	        echo json_encode($dataToReturn);
	        die();
		}

		$gst_number = $this->Vendor_model->gst_check($gst_number);

		if (!empty($gst_number)) {
			$dataToReturn['status']   =  false;
	        $dataToReturn['msg']      =  'GST Number Already Exist';
	        echo json_encode($dataToReturn);
	        die();
		}

		
		/*=======*/

		$data = array(

			'user-type' => $this->input->post('user-type'),
			'name' => $this->input->post('name'),
			'email' => $this->input->post('email'),
			'number' => $this->input->post('number'),
			'company_name' => $this->input->post('company-name'),
			'gst_number' => $this->input->post('gst-number'),
			'labour_license' => $this->input->post('labour-license'),
			'password' => $this->input->post('password'),
			'about_me' => $this->input->post('about-me'),

		);


		$result = $this->Vendor_model->register_vender_date($data);
			if ($result==true) {
		        $dataToReturn['status'] = true;
		        $dataToReturn['msg'] = ' Register Successfully ';
		    }else{
		        $dataToReturn['status'] = false;
		        $dataToReturn['msg'] = 'Something Went Wrong';
		    }
		        echo  json_encode($dataToReturn);
	}

	/*login_vender*/

	public function login_vender(){

		$username = $this->input->post('username');
		$user_type = $this->input->post('user-type');
	    $password = $this->input->post('password');

	    /*validation*/
	    if($user_type ==  "" ){
           $dataToReturn['status']   =  false;
           $dataToReturn['msg']      =  'Select User Type';
           echo json_encode($dataToReturn);
           die();
        }

	    if($username ==  "" ){
           $dataToReturn['status']   =  false;
           $dataToReturn['msg']      =  'Please Enter Username';
           echo json_encode($dataToReturn);
           die();
        }

        if($password ==  "" ){
           $dataToReturn['status']   =  false;
           $dataToReturn['msg']      =  'Please Enter Password';
           echo json_encode($dataToReturn);
           die();
        }

        if(!filter_var($username, FILTER_VALIDATE_EMAIL)){
	        $dataToReturn['status']   =  false;
	        $dataToReturn['msg']      =  'Enter Valid Username';
	        echo json_encode($dataToReturn);
	        die();
        }
     
        $email_ = $this->Vendor_model->username_check($username);

            if(empty($email_)){
            $dataToReturn['status']   =  false;
            $dataToReturn['msg']      =  'Username Not Exits';
            echo json_encode($dataToReturn);
            die();
        }

        $pass = $this->Vendor_model->check_pass($password);

            if(empty($pass)){
            $dataToReturn['status']   =  false;
            $dataToReturn['msg']      =  'Incorrect Password';
            echo json_encode($dataToReturn);
            die();
        }
        


        /*password check*/
        if (strlen($password) < 6 || $password=='' || strlen($password) >= 21) {
            $dataToReturn['status']   = 'err';
            $dataToReturn['msg']      = 'Incorrect Password';
            $dataToReturn['types']    =  'PASS';
            echo json_encode($dataToReturn);
            die();
        }





		$result = $this->Vendor_model->login_vender_data($username,$password);
		// _dx($result);
			if (!empty($result)) {
				$array_login = array(
					'vendor_id' => $result[0]->id,
					'vendor_name' => $result[0]->name,
					'vendor_email' => $result[0]->email,
				);
				// die();
				$this->session->set_userdata($array_login);
		        $dataToReturn['status'] = true;
		        $dataToReturn['msg'] = ' Login Successfully ';
		    }else{
		        $dataToReturn['status'] = false;
		        $dataToReturn['msg'] = 'Something Went Wrong';
		    }
		        echo  json_encode($dataToReturn);
		}


		/*chnage profile*/

		public function chnage_profile(){
			
			$ImgVideoFiles = '';

			if (isset($_FILES['file']['name'])) {
            if ($_FILES['file']['name'] != '') {
              $ImgVideoFiles = $_FILES['file']['name'];
              $target_dir = "assets/images/vendor_img/";
              $target_file = $target_dir . basename($_FILES["file"]["name"]);
              move_uploaded_file($_FILES["file"]["tmp_name"], $target_file);
            }
          }

          
          $id = $this->input->post('id');
          $data['image'] =$ImgVideoFiles ;

			$result = $this->Vendor_model->vender_profile_img($id,$data);
			if ($result == true) {
				redirect('vendor-dashboard', 'refresh');
			}
			else{
				redirect('vendor-dashboard', 'refresh');
			}
		}

		/*update vender*/
		public function update_vender(){



			$id = $this->input->post('id');
		$data = array(

			'name' => $this->input->post('name'),
			'number' => $this->input->post('number'),
			'email' => $this->input->post('email'),
			'company_name' => $this->input->post('company_name'),
			'gst_number' => $this->input->post('gst_number'),
			'labour_license' => $this->input->post('labour_license'),
			'about_me' => $this->input->post('about_me'),
			'project_handle' => $this->input->post('project_handle'),
			'current_project' => $this->input->post('current_project'),
			'past_project' => $this->input->post('past_project'),

		);


		$result = $this->Vendor_model->update_vender_data($id,$data);
			if ($result==true) {
		        $dataToReturn['status'] = true;
		        $dataToReturn['msg'] = ' Update Successfully ';
		    }else{
		        $dataToReturn['status'] = false;
		        $dataToReturn['msg'] = 'Something Went Wrong';
		    }
		        echo  json_encode($dataToReturn);
		}



}
