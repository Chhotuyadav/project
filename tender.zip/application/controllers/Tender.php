<?php

class Tender extends CI_Controller
{
	
	public function tender_list()
	{
		$this->load->view('tender/tender-list');
	}

	public function tender_details()
	{
		$this->load->view('tender/tender-details');
	}
}