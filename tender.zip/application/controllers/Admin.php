<?php

class Admin extends CI_Controller
{

	public function __construct(){
		parent::__construct();
		$this->load->model('Admin_model');
	}
	
	public function index(){
		$this->load->view('admin/index');
	}

	public function admin_login(){

		$email = $this->input->post('user-email');
		$password = $this->input->post('user-pass');

		/*validation*/

	    if($email ==  "" ){
           $dataToReturn['status']   =  false;
           $dataToReturn['msg']      =  'Please Enter Email';
           echo json_encode($dataToReturn);
           die();
        }

        if($password ==  "" ){
           $dataToReturn['status']   =  false;
           $dataToReturn['msg']      =  'Please Enter Password';
           echo json_encode($dataToReturn);
           die();
        }

        	$result = $this->Admin_model->admin_check($email,$password);
			if (!empty($result)) {
				$array_a = array(
					'admin_id' => $result[0]->id,
				);

				$this->session->set_userdata($array_login);
		        $dataToReturn['status'] = true;
		        $dataToReturn['msg'] = ' Login Successfully ';
		    }else{
		        $dataToReturn['status'] = false;
		        $dataToReturn['msg'] = 'Something Went Wrong';
		    }
		        echo  json_encode($dataToReturn);
		}


	public function dashboard(){
		$this->load->view('admin/dashboard');
	}

	/*admin/vendor*/
	public function vendor_all_vendors(){
		$this->load->view('admin/vendor/all-vendors');
	}
	public function vendor_current_project(){
		$this->load->view('admin/vendor/current-project');
	}
	public function vendor_complete_project(){
		$this->load->view('admin/vendor/complete-project');
	}
	public function vendor_pending_project(){
		$this->load->view('admin/vendor/pending-project');
	}

	/*admin/company*/
	public function company_all_company(){
		$this->load->view('admin/company/all-company');
	}
	public function company_current_project(){
		$this->load->view('admin/company/current-project');
	}
	public function company_complete_project(){
		$this->load->view('admin/company/complete-project');
	}
	public function company_pending_project(){
		$this->load->view('admin/company/pending-project');
	}


}