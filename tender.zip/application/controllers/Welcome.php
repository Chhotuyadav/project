<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('Vendor_model');
		$this->load->model('Company_model');

		
	}


    
	public function index()
	{
		if ($this->session->userdata('vendor_id')) {
			return redirect(base_url('vendor-dashboard'));
		}
		// _dx($this->session->userdata());
		$this->load->view('vendor/index');
	}
	
	public function register()
	{
		if ($this->session->userdata('vendor_id')) {
			return redirect(base_url('vendor-dashboard'));
		}
		$this->load->view('vendor/register');
	}

	public function vendor_dashboard()
	{	
		if (!$this->session->userdata('vendor_id')) {
			return redirect(base_url('/'));
		}
		$Vendor_id = $this->session->userdata('vendor_id');
		$result['data'] = $this->Vendor_model->get_vendor_details($Vendor_id); 
		$this->load->view('vendor/vendor-dashboard',$result);
	}

	public function register_user()
	{
		$this->load->view('vendor/register-user');
	}
    
    public function vendor_view()
	{
		$this->load->view('vendor/vendor-view');
	}

	public function vendor_profile()
	{
		$this->load->view('vendor/vendor-profile');
	}
	
	public function tendor_list()
	{
		$this->load->view('vendor/tendor-list');
	}
    public function tendor_details()
	{
		$this->load->view('vendor/tendor-details');
	}
	public function logout(){
		$this->session->sess_destroy();
		return redirect(base_url('/'));
	}


	/*company*/

	public function company_dashboard()
	{
		if (!$this->session->userdata('company_id')) {
			return redirect(base_url('/'));
		}
		$company_id = $this->session->userdata('company_id');
		$result['data'] = $this->Company_model->get_company_details($company_id);
		$this->load->view('company/company-dashboard',$result);
	}

}
