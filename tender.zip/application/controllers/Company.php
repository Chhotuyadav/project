<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Company extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('Company_model');
	}

	/*register company*/

	public function register_company(){

		 $company_name  =  $this->input->post('company_name');
		 $email  =  $this->input->post('email');
		 $gst_number  =  $this->input->post('gst-number');
		 $pan_number  =  $this->input->post('pan-number');

		if ($company_name == '' ) {
			$dataToReturn['status']   =  false;
	        $dataToReturn['msg']      =  'Enter Company Name';
	        echo json_encode($dataToReturn);
	        die();
		}
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
	        $dataToReturn['status']   =  false;
	        $dataToReturn['msg']      =  'Enter Valid Email';
	        echo json_encode($dataToReturn);
	        die();
        }
		if ($pan_number == '' ) {
			$dataToReturn['status']   =  false;
	        $dataToReturn['msg']      =  'Enter Company Name';
	        echo json_encode($dataToReturn);
	        die();
		}

		$email_check = $this->Company_model->email_check($email);

		if (!empty($email_check)) {
			$dataToReturn['status']   =  false;
	        $dataToReturn['msg']      =  'Email Already Exist';
	        echo json_encode($dataToReturn);
	        die();
		}

		$gst_number = $this->Company_model->gst_check($gst_number);

		if (!empty($gst_number)) {
			$dataToReturn['status']   =  false;
	        $dataToReturn['msg']      =  'GST Number Already Exist';
	        echo json_encode($dataToReturn);
	        die();
		}

		$pan_number = $this->Company_model->pan_check($pan_number);

		if (!empty($pan_number)) {
			$dataToReturn['status']   =  false;
	        $dataToReturn['msg']      =  'Pan Number Already Exist';
	        echo json_encode($dataToReturn);
	        die();
		}


		$data = array(

			'user-type' => $this->input->post('user-type'),
			'company_name' => $this->input->post('company_name'),
			'email' => $this->input->post('email'),
			'number' => $this->input->post('number'),
			'gst_number' => $this->input->post('gst-number'),
			'labour_license' => $this->input->post('labour-license'),
			'pan_number' => $this->input->post('pan-number'),
			'password' => $this->input->post('password'),
			'about_me' => $this->input->post('about-me'),

		);
		//_dx($data);


		$result = $this->Company_model->register_company_data($data);
			if ($result==true) {
		        $dataToReturn['status'] = true;
		        $dataToReturn['msg'] = ' Register Successfully ';
		    }else{
		        $dataToReturn['status'] = false;
		        $dataToReturn['msg'] = 'Something Went Wrong';
		    }
		        echo  json_encode($dataToReturn);
	}
	/*register end*/

	/*company  login*/

	public function company_login(){

		//_dx($_POST);

		$username = $this->input->post('username');
		$user_type = $this->input->post('user-type');
	    $password = $this->input->post('password');

	    /*validation*/
	    if($user_type ==  "" ){
           $dataToReturn['status']   =  false;
           $dataToReturn['msg']      =  'Please Select Usertype';
           echo json_encode($dataToReturn);
           die();
        }
	    if($username ==  "" ){
           $dataToReturn['status']   =  false;
           $dataToReturn['msg']      =  'Please Enter Username';
           echo json_encode($dataToReturn);
           die();
        }

        if($password ==  "" ){
           $dataToReturn['status']   =  false;
           $dataToReturn['msg']      =  'Please Enter Password';
           echo json_encode($dataToReturn);
           die();
        }

        if(!filter_var($username, FILTER_VALIDATE_EMAIL)){
	        $dataToReturn['status']   =  false;
	        $dataToReturn['msg']      =  'Enter Valid Username';
	        echo json_encode($dataToReturn);
	        die();
        }
     
        $email = $this->Company_model->username_check_company($username);

            if(empty($email)){
            $dataToReturn['status']   =  false;
            $dataToReturn['msg']      =  'Username Not Exits';
            echo json_encode($dataToReturn);
            die();
        }

        $pass = $this->Company_model->check_pass($password);

            if(empty($pass)){
            $dataToReturn['status']   =  false;
            $dataToReturn['msg']      =  'Incorrect Password';
            echo json_encode($dataToReturn);
            die();
        }
        


        /*password check*/
        if (strlen($password) < 6 || $password=='' || strlen($password) >= 21) {
            $dataToReturn['status']   = 'err';
            $dataToReturn['msg']      = 'Incorrect Password';
            $dataToReturn['types']    =  'PASS';
            echo json_encode($dataToReturn);
            die();
        }


		$result = $this->Company_model->login_company_data($username,$password);
		 //_dx($result);
			if (!empty($result)) {
				$company_login = array(
					'company_id' => $result[0]->id,
					'company_name' => $result[0]->company_name,
					'company_email' => $result[0]->email,
				);
			
				$this->session->set_userdata($company_login);
		        $dataToReturn['status'] = true;
		        $dataToReturn['msg'] = ' Login Successfully ';
		    }else{
		        $dataToReturn['status'] = false;
		        $dataToReturn['msg'] = 'Something Went Wrong';
		    }
		        echo  json_encode($dataToReturn);
		}

	  /*chnage profile*/

		public function chnage_profile_company(){
			
			$ImgVideoFiles = '';

			if (isset($_FILES['file']['name'])) {
            if ($_FILES['file']['name'] != '') {
              $ImgVideoFiles = $_FILES['file']['name'];
              $target_dir = "assets/images/company_img/";
              $target_file = $target_dir . basename($_FILES["file"]["name"]);
              move_uploaded_file($_FILES["file"]["tmp_name"], $target_file);
            }
          }

          
          $id = $this->input->post('id');
          $data['image'] =$ImgVideoFiles ;

			$result = $this->Company_model->vender_profile_img($id,$data);
			if ($result == true) {
				redirect('company-dashboard', 'refresh');
			}
			else{
				redirect('company-dashboard', 'refresh');
			}
		}

		/*update_company*/

		public function update_company(){

			//_dx($_POST);


			$id = $this->input->post('id');
			$data = array(

				'company_name' => $this->input->post('company_name'),
				'email' => $this->input->post('email'),
				'number' => $this->input->post('number'),
				'gst_number' => $this->input->post('gst_number'),
				'labour_license' => $this->input->post('labour_license'),
				'pan_number' => $this->input->post('pan_number'),
				'about_me' => $this->input->post('about_me'),
				'project_handle' => $this->input->post('past_project'),
				'current_project' => $this->input->post('past_project'),
				'past_project' => $this->input->post('past_project'),

			);

			$result = $this->Company_model->update_company_date($id,$data);
			if ($result==true) {
		        $dataToReturn['status'] = true;
		        $dataToReturn['msg'] = ' Update Successfully ';
		    }else{
		        $dataToReturn['status'] = false;
		        $dataToReturn['msg'] = 'Something Went Wrong';
		    }
		        echo  json_encode($dataToReturn);



		}
	
}