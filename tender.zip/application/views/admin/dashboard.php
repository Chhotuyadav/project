    <?php


  ?>



    <!-- ////////////////////////////////////// Header //////////////////////////////////////-->

	<?php $this->load->view('common/header')?>



    <!-- /////////////////////////////////////// Sidebar /////////////////////////////////////-->

	<?php $this->load->view('common/sidebar')?>



    <!-- ////////////////////////////////////// Main Content //////////////////////////////////////-->







   <div class="app-content content">

	   <div class="content-wrapper">

	      <div class="content-header row">

	      </div>

	      <div class="content-body">

	      	

	      </div>

	   </div>

	</div>

    



    



    <!-- ////////////////////////////////////// Footer //////////////////////////////////////-->

    <?php $this->load->view('common/footer')?>



    <!-- BEGIN PAGE LEVEL JS-->

    <script src="<?= base_url()?>app-assets/js/scripts/pages/dashboard-crm.js"></script>

    <!-- END PAGE LEVEL JS-->



    

  </body>



</html>