<!DOCTYPE html>

<html>

<head>

  <title>tender</title>

  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1">





  <!-- bootstrap 5 -->

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>

  <!-- bootstrap 5 -->



  <!-- font-awesome -->

  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

  <!-- font-awesome -->



  <!-- default style -->

  <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/style.css') ?>">

  <!-- toster -->
  <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/toastr.css') ?>">
  <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/toastr.min.css') ?>">

  <!-- default style -->
  
  <!-- font awesome cdn -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>

<body>



  <section class="header fixed-top">

    <nav class="navbar navbar-expand-lg ">

      <div class="container-fluid">

        <a class="navbar-brand" href="<?= base_url() ?>">
          <h2>LOGO</h2>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">

          <span class="navbar-toggler-icon"></span>

        </button>

        <div class="collapse navbar-collapse nav-main" id="navbarSupportedContent">

          <ul class="navbar-nav me-auto mb-2 mb-lg-0 head_menu">

            

            

            <li class="nav-item">

              <a class="nav-link active nav-li" aria-current="page" href="<?= base_url() ?>">Home</a>

            </li>

            <li class="nav-item">

              <a class="nav-link active nav-li" aria-current="page" href="<?= base_url('tender-list') ?>">Projects</a>

            </li>

            <li class="nav-item">

              <a class="nav-link active nav-li" aria-current="page" href="#">About us</a>

            </li>

            <li class="nav-item">

              <a class="nav-link active nav-li" aria-current="page" href="#">Services</a>

            </li>

            <li class="nav-item">

              <a class="nav-link active nav-li" aria-current="page" href="#">Contact us</a>

            </li>
            

            <li class="nav-item nav-li dropdown">

              <a class="nav-link dropdown-toggle nav-li " href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">

                My Account

              </a>

              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <?php if ($this->session->userdata('vendor_id')) { ?>
                  
                  <li><a class="dropdown-item" href="<?= base_url('logout') ?>">logout</a></li>
                  
                <?php  } else{  ?>
                  <li><a class="dropdown-item" href="<?= base_url() ?>">Login</a></li>


                  <li><a class="dropdown-item" href="<?= base_url('register') ?>">Register</a></li>

                <?php } ?>
                

              </ul>

            </li>

          </ul>

          <form class="d-flex">

            

            <button class="btn btn-primary search-btn" type="submit">Search</button>

          </form>

        </div>

      </div>

    </nav>

  </section>

  <script type="text/javascript">
    var url = '<?= base_url() ?>' 
  //console.log(url'/vendor-dashboard')
</script>

