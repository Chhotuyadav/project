<!-- ============Side bar tender info======= -->
    <div class="row sidebar-tend">    
        
            <div class="tender-search">
              <div class="heading"><span class="icon-tend"><i class="fa-solid fa-magnifying-glass"></i></span><span class="text-center right_title">Tendor Search</span></div>
              <div class="input-go">
                <div class="col-sm-12">
                  <span><input type="Search" class="form-control go-search" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Search"></span>
                </div>
              </div>
              <div class="advance_search"><strong>Advance Search</strong></div>
            
        
            <div class="tender-info">
              <a><i class="fa-solid fa-right-long"></i><strong>Help for Contractors</strong>
              </a>
            </div>
            <div class="tender-info">
              <a><i class="fa-solid fa-right-long"></i><strong>Help for Contractors</strong>
              </a>
            </div>
            <div class="tender-info">
              <a><i class="fa-solid fa-right-long"></i><strong>Help for Contractors</strong>
              </a>
            </div>
            <div class="tender-info">
              <a><i class="fa-solid fa-right-long"></i><strong>Help for Contractors</strong>
              </a>
            </div>
            <div class="tender-info">
              <a><i class="fa-solid fa-right-long"></i><strong>Help for Contractors</strong>
              </a>
            </div>
            <div class="tender-info">
              <a><i class="fa-solid fa-right-long"></i><strong>Help for Contractors</strong>
              </a>
            </div>
            <div class="tender-info">
              <a><i class="fa-solid fa-right-long"></i><strong>Help for Contractors</strong>
              </a>
            </div>
            <div class="tender-info">
              <a><i class="fa-solid fa-right-long"></i><strong>Help for Contractors</strong>
              </a>
            </div>
            <div class="tender-info">
              <a><i class="fa-solid fa-right-long"></i><strong>Help for Contractors</strong>
              </a>
            </div>
            <div class="tender-info">
              <a><i class="fa-solid fa-right-long"></i><strong>Help for Contractors</strong>
              </a>
            </div>
            
            
        </div>
        
    </div>
<!-- ============Side bar tender info======= -->