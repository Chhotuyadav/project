<!-- ============Side bar About company======= -->
  <div class="row sidebar-about">
    <div class="about-company">
       <div class="heading"><span class="left_title">About Company</span></div>
       <p>Sidebar, Inc. delivers intelligent, personalized mobile merchandising solutions to maximize revenue from mobile content delivers intelligent, personalized mobile merchandising solutions to maximize revenue from mobile content Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
       tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
       quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
       consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
       cillum dolore eu fugiat nulla pariatur.    </p>
      
       <div class="side_icon"><p><a><i class="fa-solid fa-users"></i>11-50</a></p></div>
       <div class="side_icon"><p><a><i class="fa-solid fa-flag"></i>Private</a></p></div>
       <div class="side_icon"><p><a><i class="fa-solid fa-earth-africa"></i>sidebar.com</a></p></div>
       <div class="side_icon"><p><a><i class="fa-solid fa-ranking-star"></i>198,020</a></p></div>
    </div>
  </div>
<!-- ============Side bar About company======= -->