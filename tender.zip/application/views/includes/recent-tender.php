<div class="container-fluid ">
	<div class="row">
		<marquee onmouseover="this.stop();" onmouseout="this.start();"  scrollamount="2" direction="up">
			<div class="tender-detals">
	          <div class="row"> 
	                <div class="col-sm-8">
	                  <h6>Materials: Hammer Union Z Type Coupling</h6>
	                </div>
	                <div class="col-sm-4">
	                  <p>Deadline:<strong>25 Sep 2022</strong></p>
	                </div>
	          </div>
	          <div class="row tender-detals2">
	                <div class="col-sm-3">
	                    <span><img src="<?= base_url('assets/images/india.png') ?>" class="ind-flag"></span><strong>India</strong>
	                </div>
	                <div class="col-sm-5">
	                    <p>TOT Reference No.:<strong>71616124</strong></p>
	                </div>
	                <div class="col-sm-4">
	                <a href="<?= base_url('tender-details') ?>"  class="btn btn-view">View Details</a>
	                </div>
	          </div>
	        </div>
	        <div class="min-space"></div>

	        <!--  -->
	        <div class="tender-detals">
	          <div class="row"> 
	                <div class="col-sm-8">
	                  <h6>Materials: Hammer Union Z Type Coupling</h6>
	                </div>
	                <div class="col-sm-4">
	                  <p>Deadline:<strong>25 Sep 2022</strong></p>
	                </div>
	          </div>
	          <div class="row tender-detals2">
	                <div class="col-sm-3">
	                    <span><img src="<?= base_url('assets/images/india.png') ?>" class="ind-flag"></span><strong>India</strong>
	                </div>
	                <div class="col-sm-5">
	                    <p>TOT Reference No.:<strong>71616124</strong></p>
	                </div>
	                <div class="col-sm-4">
	                <a href="<?= base_url('tender-details') ?>" class="btn btn-view">View Details</a>
	                </div>
	          </div>
	        </div>
	        <div class="min-space"></div>
	        <!--  -->
	        <div class="tender-detals">
	          <div class="row"> 
	                <div class="col-sm-8">
	                  <h6>Materials: Hammer Union Z Type Coupling</h6>
	                </div>
	                <div class="col-sm-4">
	                  <p>Deadline:<strong>25 Sep 2022</strong></p>
	                </div>
	          </div>
	          <div class="row tender-detals2">
	                <div class="col-sm-3">
	                    <span><img src="<?= base_url('assets/images/india.png') ?>" class="ind-flag"></span><strong>India</strong>
	                </div>
	                <div class="col-sm-5">
	                    <p>TOT Reference No.:<strong>71616124</strong></p>
	                </div>
	                <div class="col-sm-4">
	                <a href="<?= base_url('tender-details') ?>" class="btn btn-view">View Details</a>
	                </div>
	          </div>
	        </div>
	        <div class="min-space"></div>
    	</marquee>

	</div>
</div>

<!-- //////// -->
<!-- <div class="container-fluid dislaimer_about_out">
	<div class="">
	
		<div class="row">
			<div class="col-sm-6 col-md-6 col-lg-6">
				<marquee  scrollamount="2" direction="up">
					<ul>
					<li>Smart City Project</li>
					<li>Swachh Bharat Abhiyan</li>
					<li>Punasa Damn Project</li>
					<li>Road Development Authority</li>
					<li>Super Corridor</li>
					<li>Indore Developpment Authority</li>
				</ul>
				</marquee>
			</div>
			<div class="col-sm-6 col-md-6 col-lg-6">
				<marquee  scrollamount="2" direction="up">
					<ul>
					<li>Super Corridor</li>
					<li>Atal Brij Project</li>
					<li>Indore Developpment Authority</li>
					<li>Narmada Shipra Sangam Project</li>
					<li>Punasa Damn Project</li>
					<li>AB Road Development</li>
				</ul>
				</marquee>
			</div>
		</div>
	</div>
</div> -->
