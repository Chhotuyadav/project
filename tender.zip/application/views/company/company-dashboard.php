<!--header-->
<? $this->load->view('includes/header.php')  ?>
<!--header-->
<div class="space"></div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-3 col-md-3 .col-lg-3">
                <? $this->load->view('includes/about-sidebar.php')  ?>
            </div>
            <div class="col-sm-9 col-md-9 .col-lg-9 middle_outer">
                <div class="container middle_inner">
                    <h3 class="text-center about_vendor">About Company </h3>

                    <div class="row">
                        <?php foreach ($data as $row): ?>

                        <div class="col-sm-8 vendor_top" >
                            <div class="row">
                                <div class="row vendor_field">
                                   <div class="col-sm-6">
                                    <strong> Company Name :</strong>
                                   </div>
                                   <div class="col-sm-6"><?= $row->company_name ?></div>
                                </div>
                                <hr>
                                <div class="row vendor_field">
                                   <div class="col-sm-6">
                                    <strong>Mobile Number :</strong>
                                   </div>
                                   <div class="col-sm-6"><?= $row->number ?></div>
                                </div>
                                <hr>
                                <div class="row vendor_field">
                                   <div class="col-sm-6">
                                    <strong>Email :</strong>
                                   </div>
                                   <div class="col-sm-6"><?= $row->email ?></div>
                                </div>
                                <hr>
                                <div class="row vendor_field">
                                    <div class="col-sm-6">
                                        <strong>PAN No. :</strong>
                                    </div>
                                    <div class="col-sm-6"><?= $row->pan_number ?></div>
                                </div>
                            <hr>
                                <div class="row vendor_field">
                                   <div class="col-sm-6">
                                    <strong>GSTIN NO. :</strong>
                                   </div>
                                   <div class="col-sm-6"><?= $row->gst_number ?></div>
                                </div>
                            <hr>
                                <div class="row vendor_field">
                                  <div class="col-sm-6">
                                    <strong>Labour License :</strong>
                                  </div>
                                  <div class="col-sm-6"><?= $row->labour_license ?></div>
                                </div>
                            <hr>
                            </div>
                            
                        </div>
                            <div class="col-sm-4">
                                <form class="form" id="image_upload" method="post" action="<?= base_url('chnage-profile-company') ?>" enctype="multipart/form-data" >
                                  <div class="upload">
                                    <?php 
                                    if (empty($row->image)) { ?>
                                        <img src="<?= base_url('assets/images/company_img/img_avatar.png') ?>" width = 125 height = 125 title="<?= $row->image ?>">    
                                    <?php }else{  ?>
                                    <img src="<?= base_url('assets/images/company_img/').$row->image ?>" width = 125 height = 125 title="<?= $row->image ?>">
                                    <?php } ?>
                                    <div class="round">
                                      <input type="hidden" name="id" value="<?= $row->id ?>">
                                      <input type="file" name="file" id = "image" accept=".jpg, .jpeg, .png">
                                      <i class = "fa fa-camera" style = "color: #fff;"></i>
                                    </div>
                                  </div>
                                </form>
                            </div>
                       </div>
                            <div class="row vendor_bottom">
                                
                                    <div class="row vendor_field">
                                      <div class="col-sm-4">
                                        <strong>About me :</strong>
                                      </div>
                                      <div class="col-sm-8"><?= $row->about_me ?></div>
                                    </div><hr>
                                    <div class="row vendor_field">
                                      <div class="col-sm-4">
                                        <strong>Project Handle :</strong>
                                      </div>
                                      <div class="col-sm-8"><?= $row->project_handle ?></div>
                                    </div><hr>
                                    <div class="row vendor_field">
                                      <div class="col-sm-4">
                                        <strong>Current Project :</strong>
                                      </div>
                                      <div class="col-sm-8"><?= $row->project_handle ?></div>
                                    </div><hr>
                                    <div class="row vendor_field">
                                      <div class="col-sm-4">
                                        <strong>Past Project :</strong>
                                      </div>
                                      <div class="col-sm-8"><?= $row->past_project ?>
                                      </div>
                                    </div><hr>
                                
                            </div>
                            <!-- =============model================== -->
                            <button type="button" data-bs-toggle="modal" data-bs-target="#company-update<?= $row->id ?>" class="btn btn-outline-info">Edit Profile</button>
                            <!-- Modal -->
                            <div class="modal fade" id="company-update<?= $row->id ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                              <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Update Profile</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                  </div>
                                  <div class="modal-body form-group">
                                    <form class="update-company">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <div class="form-group">
                                                    <input type="hidden" name="id" value="<?= $row->id ?>">
                                                    <input type="text" placeholder="Enter Comapny Name" class="form-control item" name="company_name"
                                                    value="<?= $row->company_name ?>" >
                                                </div>
                                            </div>
                                            <div class="col-sm-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control item" name="number"
                                                    value="<?= $row->number ?>" placeholder="Enter Number" >
                                                </div>
                                            </div>
                                            <div class="col-sm-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control item" name="email"
                                                    value="<?= $row->email ?>" placeholder="Enter Email Address">
                                                </div>
                                            </div>
                                            <div class="min-space"></div>
                                            <div class="col-sm-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control item" name="pan_number"   value="<?= $row->pan_number ?>" placeholder="Pan Number">
                                                </div>
                                            </div>
                                            <div class="col-sm-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control item" name="gst_number" value="<?= $row->gst_number ?>" placeholder="Enter GST Number">
                                                </div>
                                            </div>
                                            <div class="col-sm-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control item" name="labour_license"
                                                    value="<?= $row->labour_license ?>" placeholder="Enter labour license">
                                                </div>
                                            </div>
                                            <div class="min-space"></div>
                                            <div class="col-sm-6">
                                                <label><b>About me:</b></label>
                                                <div class="form-group">
                                                    <textarea class="form-control item" rows="4" name="about_me"><?= $row->about_me ?></textarea>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label><b>Project Handle:</b></label>
                                                <div class="form-group">
                                                    <textarea class="form-control item" rows="4" name="project_handle"><?= $row->project_handle ?></textarea>
                                                </div>
                                            </div>
                                            <div class="min-space"></div>
                                            <div class="col-sm-6">
                                                <label><b>Current Project:</b></label>
                                                <div class="form-group">
                                                    <textarea class="form-control item" rows="4" name="current_project"><?= $row->current_project ?></textarea>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label><b>Past Project:</b></label>
                                                <div class="form-group">
                                                    <textarea class="form-control item" rows="4" name="past_project"><?= $row->past_project ?></textarea>
                                                </div>
                                            </div>
                                            <div class="min-space"></div>                                            
                                        </div>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Update Profile</button>
                                  </div>
                                  </form>
                                </div>
                              </div>
                            </div>
                            <!-- =============model================== -->
                    <?php endforeach ?>
                </div>
            
            </div>
            <!-- <div class="col-sm-3 col-md-3 .col-lg-3">
                <? /*$this->load->view('includes/news-sidebar.php')*/  ?>
            </div> -->
        </div>
    </div>
<div class="max-space"></div>


<!--footer-->
<? $this->load->view('includes/footer.php')  ?>
<!--footer-->
<script src="<?= base_url('assets/js/login.js">')?>"></script>
<script type="text/javascript">
document.getElementById("image").onchange = function(){
  var val = document.getElementById("image_upload").submit();
  //console.log(val);
};
</script>