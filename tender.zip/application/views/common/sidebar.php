<div class="main-menu menu-fixed menu-dark menu-accordion    menu-shadow " data-scroll-to-active="true">

   <div class="main-menu-content">

      <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">



         <li class=" nav-item">

            <a href="<?= base_url('admin/dashboard')?>">

               <i class="icon-home"></i>

               <span class="menu-title" data-i18n="nav.dash.main">Dashboard</span>

            </a>

         </li>


         <!-- View Vendor -->
         <li class=" nav-item">

            <a href="javascript:void(0);">

               <i class="icon-layers"></i>

               <span class="menu-title" data-i18n="nav.dash.main">View Vendor</span>

               <span class="badge badge badge-info badge-pill float-right mr-2">4</span>

            </a>

            <ul class="menu-content">

               <li>
                  <a class="menu-item" href="<?= base_url('admin/all-vendors')?>" data-i18n="nav.dash.ecommerce">
                        All Vendors
                  </a>
               </li>
               <li>
                  <a class="menu-item" href="<?= base_url('admin/vendor/current-project')?>" data-i18n="nav.dash.ecommerce">
                        Current project
                  </a>
               </li>
               <li>
                  <a class="menu-item" href="<?= base_url('admin/vendor/completed-project')?>" data-i18n="nav.dash.ecommerce">
                        Completed Project
                  </a>
               </li>
               <li>
                  <a class="menu-item" href="<?= base_url('admin/vendor/pending-project')?>" data-i18n="nav.dash.ecommerce">
                        Pending Project
                  </a>
               </li>

            </ul>

         </li>
         <!-- View Company -->
         <li class=" nav-item">

            <a href="javascript:void(0);">

               <i class="icon-layers"></i>

               <span class="menu-title" data-i18n="nav.dash.main">View Company</span>

               <span class="badge badge badge-info badge-pill float-right mr-2">4</span>

            </a>

            <ul class="menu-content">

               <li>
                  <a class="menu-item" href="<?= base_url('admin/all-company')?>" data-i18n="nav.dash.ecommerce">
                        All Company
                  </a>
               </li>
               <li>
                  <a class="menu-item" href="<?= base_url('admin/company/current-project')?>" data-i18n="nav.dash.ecommerce">
                        Current project
                  </a>
               </li>
               <li>
                  <a class="menu-item" href="<?= base_url('admin/company/completed-project')?>" data-i18n="nav.dash.ecommerce">
                        Completed Project
                  </a>
               </li>
               <li>
                  <a class="menu-item" href="<?= base_url('admin/company/pending-project')?>" data-i18n="nav.dash.ecommerce">
                        Pending Project
                  </a>
               </li>

            </ul>

         </li>

         



         <li class=" nav-item">

            <a href="<?= base_url('/country-list')?>">

               <i class="icon-globe"></i>

               <span class="menu-title" data-i18n="nav.dash.main">Country</span>

            </a>

         </li>

         



         <li class=" nav-item">

            <a href="<?= base_url('/province')?>">

               <i class="ft-cloud"></i>

               <span class="menu-title" data-i18n="nav.dash.main">Province</span>

            </a>

         </li>

         

      </ul>

   </div>

</div>