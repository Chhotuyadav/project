<!--header-->
<?php $this->load->view('includes/header.php')  ?>
<!--header-->
<div class="space"></div>

<div class="container-fluid ">
	<div class="tender-details">
		<div class="row ten-details">

			<div class="col-sm-9 col-md-9 col-lg-9 ">

				<div>
					<h5><span>Tender Reference No:</span> 51843190</h5>
				</div>
				<div class="ten-disc shadow-sm p-3 mb-3 bg-body rounded">
					<p><span>Requirement :	</span>Construction of uni-directional singhpora - vailoo tunnel (under sinthanpass) of length 10.331km/10.363km (tube-1/tube-2) and its approach road of total length 38.611 km in union territory of jammu and kashmir on epc mode.</p>
				</div>

				<div class="file">
					<h3>Tender Documents </h3>

					<li>
						<a href="#" onclick="OpenRegistration(53965733)" class="ui-link">
							<i><img style="width: 35px; padding-right: 10px;" src="assets/images/download.png" alt="PDF File"></i>
							<p>Document 2.pdf <span>(123.72 KB) <i class="fa-solid fa-download"></i></span></p></a>
						</li>


						<li>
							<a href="#" onclick="OpenRegistration(53965733)" class="ui-link">
								<i><img style="width: 35px; padding-right: 10px;" src="assets/images/download.png" alt="PDF File"></i>
								<p>Document 2.pdf <span>(123.72 KB) <i class="fa-solid fa-download"></i></span></p></a>
							</li>
						</div>

						<div class="table1">
						<table class="table table-striped">
							<thead>
								<tr>
									<th class="table-info table-active text-center" colspan="5"  scope="col">Probable Participants</th>							 
								</tr>
								<tr>
									<th scope="col">S no.</th>
									<th scope="col">Bidder Name</th>
									<th scope="col">Location</th>
									<th scope="col">Buisness Categories</th>
									<th scope="col">Bid History</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<th scope="row">1</th>
									<td>M/s Beigh Construction Pvt. Ltd.</td>
									<td class="text-center"><i class="fa-solid fa-location-dot"></i></td>
									<td class="text-center"><i class="fa-solid fa-list"></i></td>
									<td class="text-center"><i class="fa-solid fa-chart-area"></i></td>
								</tr>
								<tr>
									<th scope="row">2</th>
									<td>M/s APCO Infratech Pvt. Ltd</td>
									<td class="text-center"><i class="fa-solid fa-location-dot"></i></td>
									<td class="text-center"><i class="fa-solid fa-list"></i></td>
									<td class="text-center"><i class="fa-solid fa-chart-area"></i></td>
								</tr>
								<tr>
									<th scope="row">3</th>
									<td>Shiva Structures Pvt. Ltd.</td>
									<td class="text-center"><i class="fa-solid fa-location-dot"></i></td>
									<td class="text-center"><i class="fa-solid fa-list"></i></td>
									<td class="text-center"><i class="fa-solid fa-chart-area"></i></td>
								</tr>
								<tr>
									<th scope="row">4</th>
									<td colspan="">Rk Infracorp Pvt Ltd</td>
									<td class="text-center"><i class="fa-solid fa-location-dot"></i></td>
									<td class="text-center"><i class="fa-solid fa-list"></i></td>
									<td class="text-center"><i class="fa-solid fa-chart-area"></i></td>
								</tr>
							</tbody>
						</table>
						</div>

					</div>


					<div class="col-sm-3 col-md-3 .col-lg-3 tender-Value">



						<div class="col-12 bg-light p-3 border">
							<div class="ten-result">
								<a href="#"><div>
									<br><img src="assets/images/image.png"><br><br>
									<strong>78 Tender Result</strong>
									<span><p> found for your category of interest</p></span>
								</div></a>
							</div><br>
							<div>
								<div class="advance_search"><strong>Tender Value</strong></div>
								<p>Tender Estimated Cost</p>
								<h6>32.53 Cr.</h6>
							</div>
						</div>
						<div class="col-sm-12 bg-light p-3 border">
							<div>
								<div class="advance_search"><strong>Key Dates</strong></div>
								<p>Due on</p>
								<h6>29 September 2022</h6>
							</div>
						</div>
						<div class="col-sm-12 bg-light p-3 border">
							<div>
								<div class="advance_search"><strong>Location:-</strong>Jammu-kashmir , India</div>
								<p>Contact Details</p>
								<h6>Can be viewed by Subscribers</h6>
							</div>
						</div>
						<div class="col-sm-12 bg-light p-3 border">
							<div>
								<div class="advance_search"><strong>Tender Key Hashtags</strong></div>
								<p>#tunnel tenders</p>

							</div>
						</div>

					</div>
				</div>

			</div>
		</div>
<?php $this->load->view('includes/footer.php')  ?>




