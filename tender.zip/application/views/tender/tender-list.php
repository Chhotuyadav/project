<!--header-->
<?php $this->load->view('includes/header.php')  ?>
<!--header-->
<div class="space"></div>

<div class="container-fluid">
	<div class="row">
		<div class="col-sm-9 col-md-9 col-lg-9 ">
			<div class="table1 ten-details">
				<div class="left_title t-list">Tender List:-</div>
					<table>
						<thead class="bg-dark">
						<tr>
							<th>S No.</th>	
							<th>Subject</th>
							<th>Duration </th>
							<th>Amount</th>
							<th>No. of Bide</th>
							<th>Open/Close</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>1</td>
							<td>
								<div class="d-flex align-items-center">
									<div class="ms-3">
						              	<p class="fw-bold mb-1">John Doe</p>
						              	<p class="text-muted mb-0">john.doe@gmail.com</p>
			              			</div>
			          			</div>
						    </td>
						      <td>
						      	<p class="fw-normal mb-1">3 months</p>
						      	<p class="text-muted mb-0">IT department</p>
						      </td>
						      <td>2,00,000 to 10,00,000 Rs.</td>
						      <td>30</td>
						      <td>
						      	<p class="text-muted mb-0">Tender opening date:-30/09/2022</p>
						      	<p class="text-muted mb-0">Tender closing date:-30/09/2022</p>
						      </td>
						      	<td>
						      		<a class="btn btn-primary " href="<?= base_url('tender-details') ?>">View</a>
						      	</td>
						</tr>
						<tr>
							<td>1</td>
							<td>
								<div class="d-flex align-items-center">
									<div class="ms-3">
						              	<p class="fw-bold mb-1">John Doe</p>
						              	<p class="text-muted mb-0">john.doe@gmail.com</p>
			              			</div>
			          			</div>
						    </td>
						      <td>
						      	<p class="fw-normal mb-1">3 months</p>
						      	<p class="text-muted mb-0">IT department</p>
						      </td>
						      <td>2,00,000 to 10,00,000 Rs.</td>
						      <td>30</td>
						      <td>
						      	<p class="text-muted mb-0">Tender opening date:-30/09/2022</p>
						      	<p class="text-muted mb-0">Tender closing date:-30/09/2022</p>
						      </td>
						      	<td>
						      		<a class="btn btn-primary " href="<?= base_url('tender-details') ?>">View</a>
						      	</td>
						</tr>
						<tr>
							<td>1</td>
							<td>
								<div class="d-flex align-items-center">
									<div class="ms-3">
						              	<p class="fw-bold mb-1">John Doe</p>
						              	<p class="text-muted mb-0">john.doe@gmail.com</p>
			              			</div>
			          			</div>
						    </td>
						      <td>
						      	<p class="fw-normal mb-1">3 months</p>
						      	<p class="text-muted mb-0">IT department</p>
						      </td>
						      <td>2,00,000 to 10,00,000 Rs.</td>
						      <td>30</td>
						      <td>
						      	<p class="text-muted mb-0">Tender opening date:-30/09/2022</p>
						      	<p class="text-muted mb-0">Tender closing date:-30/09/2022</p>
						      </td>
						      	<td>
						      		<a class="btn btn-primary " href="<?= base_url('tender-details') ?>">View</a>
						      	</td>
						</tr>
			        </tbody>
		        </table>
			</div>
		</div>
		<div class="col-sm-3 col-md-3 .col-lg-3">
			<?php  $this->load->view('includes/news-sidebar.php')  ?>
		</div>	
	</div>
</div>
<?php $this->load->view('includes/footer.php')  ?>
