<?php



function _dx($data){

    echo "<pre>";

    print_r($data);

    echo "</pre>";

    die;

}


function isLogin($thisObj){
    if ($thisObj->session->userdata('vender_id') == '') {
        // return redirect(base_url('/'));
    }else{
        return TRUE;
    }
}