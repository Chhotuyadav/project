<?php include('common/header.php') ?>

<!-- ======================= Start Page Title ===================== -->
<div class="page-title">
  <div class="container">
    <div class="page-caption">
      <h2>Add Job</h2>
      <p><a href="#" title="Home">Home</a> <i class="ti-angle-double-right"></i> Add Job</p>
    </div>
  </div>
</div>
<!-- ======================= End Page Title ===================== --> 

<!-- ======================= Create Job ===================== -->
<section class="create-job padd-top-80 padd-bot-80">
  <div class="container" data-aos="fade-up">
    <form class="c-form">
      <!-- General Information -->
      <div class="box">
        <div class="box-header">
          <h4>General Information</h4>
        </div>
        <div class="box-body">
          <div class="row">
            <div class="col-md-4 col-sm-6 col-xs-12">
              <label>Job Title</label>
              <input type="text" class="form-control" placeholder="Job Title">
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
              <label>Company Name</label>
              <input type="text" class="form-control" placeholder="Company Name">
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
              <label>Category</label>
              <select class="wide form-control">
                <option data-display="Location">Information Of Technology</option>
                <option value="1">Hardware</option>
                <option value="2">Machanical</option>
              </select>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 m-clear">
              <label>Description</label>
              <input type="text" class="form-control" placeholder="Description">
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
              <label>Salary Range</label>
              <select class="wide form-control">
                <option data-display="Salary Range">2,0000</option>
                <option value="1">3,0000</option>
                <option value="2">4,0000</option>
              </select>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 m-clear">
              <label>No. Of Vacancy</label>
              <input type="text" class="form-control" placeholder="No. Of Vacancy">
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 m-clear">
              <label>Experience</label>
              <select class="wide form-control">
                <option data-display="Experience">0 To 6 Month</option>
                <option value="1">1 Year</option>
                <option value="2">2 Year</option>
              </select>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 m-clear">
              <label>Company Logo</label>
              <div class="custom-file-upload">
                <input type="file" id="file" name="myfiles[]" multiple />
              </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 m-clear">
              <label>Job Type</label>
              <select class="wide form-control">
                <option data-display="Job Type">Full Time</option>
                <option value="1">Part Time</option>
                <option value="2">Freelancer</option>
              </select>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-12 m-clear">
              <label>Qualification Required</label>
              <input type="text" class="form-control" placeholder="Qualification">
            </div>
            <div class="col-md-6 col-sm-6 col-xs-12">
              <label>Skills(Seperate with Comma)</label>
              <input type="text" class="form-control" placeholder="Skills">
            </div>
          </div>
        </div>
      </div>
      
      <!-- Company Address -->
      <div class="box">
        <div class="box-header">
          <h4>Company Address</h4>
        </div>
        <div class="box-body">
          <div class="row">
            <div class="col-md-4 col-sm-6 col-xs-12">
              <label>Email</label>
              <input type="email" class="form-control" placeholder="Email">
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
              <label>Phone Number</label>
              <input type="text" class="form-control" placeholder="Phone Number">
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
              <label>Website Link</label>
              <input type="text" class="form-control" placeholder="Website Link">
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
              <label>Address</label>
              <input type="text" class="form-control" placeholder="Address">
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
              <label>City</label>
              <select class="wide form-control">
                  <option data-display="State">Afghanistan</option>
                  <option value="1">Albania</option>
				  <option value="2">Algeria</option>
				  <option value="3">Brazil</option>
				  <option value="4">Burundi</option>
				  <option value="5">Bulgaria</option>
				  <option value="6">Germany</option>
				  <option value="7">Grenada</option>
				  <option value="8">Guatemala</option>
				  <option value="9" disabled>Iceland</option>
              </select>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 m-clear">
              <label>State</label>
              <select class="wide form-control">
                  <option data-display="State">Afghanistan</option>
                  <option value="1">Albania</option>
				  <option value="2">Algeria</option>
				  <option value="3">Brazil</option>
				  <option value="4">Burundi</option>
				  <option value="5">Bulgaria</option>
				  <option value="6">Germany</option>
				  <option value="7">Grenada</option>
				  <option value="8">Guatemala</option>
				  <option value="9" disabled>Iceland</option>
              </select>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 m-clear">
              <label>Country</label>
              <select class="wide form-control">
                  <option data-display="State">Afghanistan</option>
                  <option value="1">Albania</option>
				  <option value="2">Algeria</option>
				  <option value="3">Brazil</option>
				  <option value="4">Burundi</option>
				  <option value="5">Bulgaria</option>
				  <option value="6">Germany</option>
				  <option value="7">Grenada</option>
				  <option value="8">Guatemala</option>
				  <option value="9" disabled>Iceland</option>
              </select>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 m-clear">
              <label>Zip Code</label>
              <input type="text" class="form-control" placeholder="Zip Code">
            </div>
          </div>
        </div>
      </div>
      
      <!-- Social Accounts -->
      <div class="box">
        <div class="box-header">
          <h4>Social Accounts</h4>
        </div>
        <div class="box-body">
          <div class="row">
            <div class="col-md-4 col-sm-6 col-xs-12">
              <label>Facebook</label>
              <input type="text" class="form-control" placeholder="https://www.facebook.com">
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
              <label>Google +</label>
              <input type="text" class="form-control" placeholder="https://www.gmail.com">
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
              <label>Twitter</label>
              <input type="text" class="form-control" placeholder="https://twitter.com">
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
              <label>LinkedIn</label>
              <input type="text" class="form-control" placeholder="https://www.linkedin.com">
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
              <label>Pinterest</label>
              <input type="text" class="form-control" placeholder="https://www.pinterest.com">
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
              <label>Instagram</label>
              <input type="text" class="form-control" placeholder="http://instagram.com">
            </div>
          </div>
        </div>
      </div>
      <div class="text-center">
        <button type="submit" class="btn btn-m theme-btn full-width">Submit</button>
      </div>
    </form>
  </div>
</section>
<!-- ====================== End Create Job ================ --> 

<section class="newsletter theme-bg" style="background-image:url(assets/img/bg-new.png)">
  <div class="container">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">
        <div class="heading light">
          <h2>Subscribe Our Newsletter!</h2>
          <p>Lorem Ipsum is simply dummy text printing and type setting industry Lorem Ipsum been industry standard dummy text ever since when unknown printer took a galley.</p>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6 col-sm-6 col-md-offset-3 col-sm-offset-3">
        <div class="newsletter-box text-center">
          <div class="input-group"> <span class="input-group-addon"><span class="ti-email theme-cl"></span></span>
            <input type="text" class="form-control" placeholder="Enter your Email...">
          </div>
          <button type="button" class="btn theme-btn btn-radius btn-m">Subscribe</button>
        </div>
      </div>
    </div>
  </div>
</section>




<!-- Signup Code -->
<div class="modal fade" id="signin" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" id="myModalLabel1">
      <div class="modal-body">
        <!-- Nav tabs -->
        <ul class="nav nav-tabs nav-advance theme-bg" role="tablist">
          <li class="nav-item active"> <a class="nav-link" data-toggle="tab" href="#employer" role="tab"> <i class="ti-user"></i> Job Seeker</a> </li>
          <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#candidate" role="tab"> <i class="ti-user"></i> Job Provider</a> </li>
        </ul>
        <!-- Nav tabs --> 
        <!-- Tab panels -->
        <div class="tab-content"> 
          <!-- Employer Panel 1-->
          <div class="tab-pane fade in show active" id="employer" role="tabpanel">
            <form>
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Email Address">
              </div>
              <div class="form-group">
                <input type="password" class="form-control" placeholder="Password">
              </div>
              <div class="form-group"> <span class="custom-checkbox">
                <input type="checkbox" id="4">
                <label for="4"></label>
                Remember Me </span> <a href="#" title="Forget" class="fl-right">Forgot Password?</a> 
			  </div>
              <div class="form-group text-center">
                <button type="button" class="btn theme-btn full-width btn-m">LogIn</button>
              </div>
            </form>
			<div class="log-option"><span>OR</span></div>
			<div class="row">
              <div class="col-md-6"> <a href="#" title="" class="fb-log-btn log-btn"><i class="fa fa-facebook"></i> Facebook</a> </div>
              <div class="col-md-6"> <a href="#" title="" class="gplus-log-btn log-btn"><i class="fa fa-google"></i> Google</a> </div>
            </div>
          </div>
          <!--/.Panel 1--> 
          
          <!-- Candidate Panel 2-->
          <div class="tab-pane fade" id="candidate" role="tabpanel">
            <form>
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Email Address">
              </div>
              <div class="form-group">
                <input type="password" class="form-control" placeholder="Password">
              </div>
              <div class="form-group"> <span class="custom-checkbox">
                <input type="checkbox" id="44">
                <label for="44"></label>
                Remember Me </span> <a href="#" title="Forget" class="fl-right">Forgot Password?</a> 
			  </div>
              <div class="form-group text-center">
                <button type="button" class="btn theme-btn full-width btn-m">LogIn</button>
              </div>
            </form>
			<div class="log-option"><span>OR</span></div>
			<div class="row">
              <div class="col-md-6"> <a href="#" title="" class="fb-log-btn log-btn"><i class="fa fa-facebook"></i> Facebook</a> </div>
              <div class="col-md-6"> <a href="#" title="" class="gplus-log-btn log-btn"><i class="fa fa-google"></i> Google</a> </div>
            </div>
          </div>
        </div>
        <!-- Tab panels --> 
      </div>
    </div>
  </div>
</div>
<!-- End Signup -->
<div><a href="#" class="scrollup">Scroll</a></div>

<!-- Jquery js--> 
<script src="assets/js/jquery.min.js"></script> 
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script> 
<script src="assets/plugins/bootstrap/js/bootsnav.js"></script> 
<script src="assets/js/viewportchecker.js"></script> 
<script src="assets/js/slick.js"></script> 
<script src="assets/plugins/bootstrap/js/wysiphp5-0.3.0.js"></script> 
<script src="assets/plugins/bootstrap/js/bootstrap-wysiphp5.js"></script> 
<script src="assets/plugins/aos-master/aos.js"></script> 
<script src="assets/plugins/nice-select/js/jquery.nice-select.min.js"></script> 
<script src="assets/js/custom.js"></script> 
<script>
	$('#myTab a').click(function (e) {
		e.preventDefault()
		$(this).tab('show')
	})
</script> 
<script>
	$('#reservation-date').dateDropper();
</script> 
<script>
	$(window).load(function() {
	  $(".page_preloader").fadeOut("slow");;
	});	
	AOS.init();
</script>
</body>
</php>
<?php include('common/footer.php') ?>
